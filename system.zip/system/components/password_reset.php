<!DOCTYPE html>
<html lang="en">
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();


if (isset($_GET['id'])) {

$_SESSION['id']=$_GET['id'];

}else {
header('Location: ./login.php');
}
?>


<head>
	<meta charset="UTF-8">
	<title>NYC Checklist</title>
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</head>
<body>
	<div class="front-page">
			<nav  style="justify-content:space-between" class="navbar">
                
                <!---logo and background from canva--->
                <div>
				    <img class="logo" src="../img/logo.png">
                </div>  
				
				<ul>
					<li><a href="../index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="help.html">Help</a></li>
					<li><a href="feedback.html">Feedback</a></li>
                    <li><a class="signin" href="login.php">Sign In</a></li>
					<div class="dropdown" data-dropdown>
                        <button id="link" class="material-symbols-outlined" data-dropdown-button>menu</button>
                        <div class="dropdown-menu">
                            <a href="../index.html">Home</a>
					        <a href="about.html">About</a>
					        <a href="help.html">Help</a>
					        <a href="feedback.html">Feedback</a>
                            <a href="login.php">Sign In</a>
                        </div>
                    </div>
				</ul>
			</nav>
			<div class="loginBox">
		
				<div>
					<img src="../img/login-dog.png">
					<h3>reset your password</h3>
					
					
					
					
					 <form action="../php/logincheck.php" method = "post">
					 <input type="text"  name="rajitha" value="<?php echo $_SESSION['id'];?>" readonly style="padding-left: 10px;">
					 <input type="password" required name="Password" placeholder="Type your new password" autofocus style="padding-left: 10px;">
					 <input type="password" required name="CPassword" placeholder="Confirm your password" autofocus style="padding-left: 10px;">
					
					
					<?php

							  if (isset($_SESSION['reset']) && !empty($_SESSION['reset'])) {
$ss=$_SESSION["reset"];								  
							  echo '<p style="color:red;font-weight:bolt">'.$ss.' </p>' ?>
                        <?php
                        unset($_SESSION['reset']);
                    }

					?>
					
					
					  <button id="button" type="submit" name="update" class="login-button">reset</button> <br><br>
					
				</div>
			
			</div> 
			
	</div>
	<script src="../script.js"></script>
</body>
</html>
