<!DOCTYPE html>
<html lang="en">

<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();


?>
<head>
	<meta charset="UTF-8">
	<title>NYC Checklist</title>
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</head>
<body>
	<div class="front-page">
			<nav  style="justify-content:space-between" class="navbar">
                
                <!---logo and background from canva--->
                <div>
				    <img class="logo" src="../img/logo.png">
                </div>  
				
				<ul>
					<li><a href="../index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="help.html">Help</a></li>
					<li><a href="feedback.html">Feedback</a></li>
                    <li><a class="signin" href="login.php">Sign In</a></li>
					<div class="dropdown" data-dropdown>
                        <button id="link" class="material-symbols-outlined" data-dropdown-button>menu</button>
                        <div class="dropdown-menu">
                            <a href="../index.html">Home</a>
					        <a href="about.html">About</a>
					        <a href="help.html">Help</a>
					        <a href="feedback.html">Feedback</a>
                            <a href="login.php">Sign In</a>
                        </div>
                    </div>
				</ul>
			</nav>
			<div class="loginBox">
		
				<div>
					<img src="../img/login-dog.png">
					<h3>sign up</h3>
					<br>
					 <?php

							  if (isset($_SESSION['success_message_on_sign_up']) && !empty($_SESSION['success_message_on_sign_up'])) {
$ss=$_SESSION["success_message_on_sign_up"];								  
							  echo '<p style="color:green;font-weight:bolt">You have successully created your account.login <a href="./login.php">here</a> </p>' ?>
                        <?php
                        unset($_SESSION['success_message_on_sign_up']);
                    }
					
					?>
					
					
					 <form action="../php/login.php" method = "post">
					 <input type="text" required name="first_name" placeholder="first name" autofocus style="padding-left: 10px;">
					 <input type="text" required name="last_name" placeholder="last name" autofocus style="padding-left: 10px;">
					 <input type="email" required name="Email" placeholder="Email" autofocus style="padding-left: 10px;">
					 <input type="password" required name="Password" placeholder="Password" style="padding-left: 10px;">
					  <button id="button" type="submit" name="sign_up" class="login-button">sign up</button> <br><br>
					
				</div>
			
			</div> 
			
	</div>
	<script src="../script.js"></script>
</body>
</html>
