<?php



$servername = "localhost";
$database = "User_info";
$username = "Rabbi";
$password = "1234";







// Create connection

$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection

if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

	$conn=mysqli_connect($servername,$username,$password,$database);
	  if(!$conn){
		  die('Could not Connect MySql Server:' .mysql_error());
		}











?>