<?php

// Start the session
session_start();

if(isset($_POST['log']))
{    
        include('./db.php');  
		
		
		 $username= $_POST['Email'];
	 $passwrd= $_POST['Password'];
		
		 $sql = "select *from user where email = '$username' and  password='$passwrd'";  

        $result = mysqli_query($conn, $sql);  

        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);



      echo  $count = mysqli_num_rows($result);  

         

        if($count > 0){
			
						
		$_SESSION['user']=	$username;
		$_SESSION['firstname']=	$row['first_name'];
   header("Location: ../index.php");

        }if($count == 0){
			
				$_SESSION['success_message']="ggggggggggg";		
			$_SESSION['first_name']=$row['v'];
			$_SESSION['last_name']=$row['last_name'];
			$_SESSION['email']=$row['email'];
			
   header("Location: ../components/login.php");
$_SESSION['success_message']="Invalid username or password";
        }
		
}






if(isset($_POST['send']))
{    
        include('./db.php');  
		
		
		 $username= $_POST['Email'];
	    $_SESSION['sendermail']=$username;
		
		 $sql = "select *from user where email = '$username'";  

        $result = mysqli_query($conn, $sql);  

        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);



      echo  $count = mysqli_num_rows($result);  

         

        if($count > 0){
			
			$_SESSION['password']=$row['password'];			
			
   header("Location: ./Email_sending/sendmail.php");

        }if($count == 0){
			
			
   header("Location: ../components/fogot_password.php");
$_SESSION['success_message']="Your Email Address is unable to find in our database";
        }
		
}



if(isset($_POST['update']))
{    
        include('./db.php');  
	 $username1=$_POST['rajitha'];
	 $passwrd1=$_POST['Password'];
	
	 $Cpasswrd1=$_POST['CPassword'];
		
	if($passwrd1==$Cpasswrd1){
	
		
 $sq="UPDATE user SET 
 `password`='$passwrd1'
 
 
 WHERE `email` ='$username1'";
 
 
 if ($conn->query($sq) === TRUE) {
	  header("Location: ../components/success.php");
 }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}else if($passwrd1 !=$Cpasswrd1){
		$_SESSION['reset']="Password confiramation failed";
		 header("Location: ../components/password_reset.php?id=$username1");
	}	
}




?>                  