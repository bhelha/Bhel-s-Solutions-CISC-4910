<?php

// Start the session
session_start();

if(isset($_POST['update']))
{    
        include('./db.php');  
	 $username=$_POST['Email'];
	 $passwrd=$_POST['Password'];
	 $Cpasswrd=$_POST['CPassword'];
		
	if($passwrd==$Cpasswrd){
		
		
		
	}else if($passwrd !=$Cpasswrd){
		$_SESSION['reset']="Password confirmation failed";
		
	}	
}










?>                  