<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();



if(isset($_POST['sign_up']))
{   
        include('./db.php');  
		
		
		    $firstname= $_POST['first_name'];
			$lastname= $_POST['last_name'];
			$email= $_POST['Email'];
			$password= $_POST['Password'];
			
		
		
		
		 $sql = "INSERT INTO user (first_name,last_name,email,password)
     VALUES ('$firstname','$lastname','$email','$password')";
     if (mysqli_query($conn, $sql)) {
		
		 $_SESSION["success_message_on_sign_up"]="on";
  	header("Location: ../components/sign_up.php");
		
		
		  
		
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
		
		
		
}



?>                  