<!DOCTYPE html>
<html lang="en">


<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();


?>
<head>
	<meta charset="UTF-8">
	<title>NYC Checklist</title>
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <script src="script.js" defer></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAeKR3s1E42hqIl6V8yR0UiMHJZxXbeAkk&callback=initMap"></script>
    <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyAeKR3s1E42hqIl6V8yR0UiMHJZxXbeAkk&callback=initMap" async defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
 
	<div class="front-page">
			<nav style="justify-content:space-between" class="navbar">
                
                <!---logo and navbar--->
                <div class="logo-section">
				    <img class="logo" src="./img/logo.png">
                </div>  
				
                <input id="searchInput" class="search" type="text" placeholder="Search events">  
<?php

  if (isset($_SESSION['firstname']) && !empty($_SESSION['firstname'])) {


$userr=$_SESSION['firstname'];
echo '<p style="font-size:20px" class="search" class="fa" > <i style="font-size:24px" class="fa">&#xf007;</i>&#160;   '.$userr.' </p>';
}
?>
				
				
				<ul>
					<li><a class="active" href="#">Home</a></li>
					<li><a href="./components/about.html">About</a></li>
					<li><a href="./components/help.html">Help</a></li>
					<li><a href="./components/feedback.html">Feedback</a></li>
                    <li><a class="signin" href="./components/login.php">Sign In</a></li>
                    <div class="dropdown" data-dropdown>
                        <button  id="link" class="material-symbols-outlined" data-dropdown-button>menu</button>
                        <div class="dropdown-menu">
						
						
						
						
						
                           
							<br>
							
							 <br>
							 <a href="index.html">Home</a>
					        <a href="./components/about.html">About</a>
					        <a href="./components/help.html">Help</a>
					        <a href="./components/feedback.html">Feedback</a>
							
							<?php

  if (isset($_SESSION['firstname']) && !empty($_SESSION['firstname'])) {


$first=$_SESSION['firstname'];
echo '<a class="signin" href="./php/logout.php">Sign out</a>';
$_SESSION['firstname']=="";

}else {
echo '<a class="signin" href="./components/login.php">Sign in</a>';

}
?>
							
							
                            
                        </div>
                    </div>

				</ul>
              
			</nav>
            <!---frontpage--->
			<div class="center">
                
                <div class="center-left">
                    
                  <div id="map"></div>

                 <!--shows the nearby restaurants in manhattan-->

                  <!-- <iframe
                    frameborder="0" style="border:0"
                    referrerpolicy="no-referrer-when-downgrade"
                    src="https://www.google.com/maps/embed/v1/search?key=AIzaSyAeKR3s1E42hqIl6V8yR0UiMHJZxXbeAkk&q=restaurants+in+Manhattan"
                    allowfullscreen>
                    </iframe>
                 -->
                <ul>
					<li>
                        <img src="./img/music.png">
                        <a onclick="getMusic()" href="#">Music</a>
                    </li>
					<li>
                        <img src="./img/artculture.png">
                        <a onclick="getArt()" href="#">Arts & Culture</a>
                    </li>
					<li>
                        <img src="./img/travel.png">
                        <a  onclick="getOutdoor()" href="#">Travel & Outdoor</a>
                    </li>
                    <li>
                        <img src="./img/food.png">
                        <a  onclick="getRestaurant()" href="#">Food & Drinks</a>
                    </li>
					<li>
                        <img src="./img/fitness.png">
                        <a  onclick="getExercise()" href="#">Health & Fitness</a>
                    </li>
					<li>
                        <img src="./img/game.png">
                        <a  onclick="getEntertainment()" href="#">Entertainment</a>
                    </li>
                    <li>
                        <img src="./img/attraction.png">
                        <a  onclick="getFun()" href="#">Attraction & Tours</a>
                    </li>
                    
                    
				</ul>
                
                 
            </div>
            <div class="center-right">
                <a href="./components/about.html"><img class="corn-guy" src="./img/corn.png" ></a>
                <div>
                    <a href=#trending>
                        <button id="button">Explore</button>
                    </a> 
            </div>
            </div> 
            </div>
            
	</div>
    
    <div id="trending" class="trending-page">
            <div> 
                <h1>TRENDING IN NYC NOW!!</h1>
            </div>
            <div>
                <img src="./img/event1.png">
                <img src="./img/event2.png">
                <img src="./img/event3.png">
                <img src="./img/event1.png">
                <img src="./img/event2.png">
                <img src="./img/event3.png">
                <img src="./img/event2.png">
                <img src="./img/event3.png">
                <img src="./img/event1.png">
                <img src="./img/event2.png">
            </div>
    </div>

</body>
</html>
